export interface CollectiblePoint {
  PointName?: string;
  Point?: number;
  MaxPoint?: number;
}
