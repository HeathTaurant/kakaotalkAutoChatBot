export interface MarketStatsInfo {
  Date?: string;
  AvgPrice?: number;
  TradeCount?: number;
}
