export interface Card {
  Slot?: number;
  Name?: string;
  Icon?: string;
  AwakeCount?: number;
  AwakeTotal?: number;
  Grade?: string;
  Tooltip?: string;
}
