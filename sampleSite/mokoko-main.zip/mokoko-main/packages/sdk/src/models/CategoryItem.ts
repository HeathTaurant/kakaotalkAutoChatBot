export interface CategoryItem {
  Code?: number;
  CodeName?: string;
}
