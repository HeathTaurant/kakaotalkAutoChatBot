export interface SkillRune {
  Name?: string;
  Icon?: string;
  Grade?: string;
  Tooltip?: string;
}
