export interface Effect {
  Name?: string;
  Description?: string;
}
