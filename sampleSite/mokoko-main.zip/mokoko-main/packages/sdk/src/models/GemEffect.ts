export interface GemEffect {
  GemSlot?: number;
  Name?: string;
  Description?: string;
  Icon?: string;
  Tooltip?: string;
}
