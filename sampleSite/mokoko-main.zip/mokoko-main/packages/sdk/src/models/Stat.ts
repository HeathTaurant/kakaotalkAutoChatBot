export interface Stat {
  Type?: string;
  Value?: string;
  Tooltip?: Array<string>;
}
