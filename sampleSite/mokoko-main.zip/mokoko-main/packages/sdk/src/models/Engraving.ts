export interface Engraving {
  Slot?: number;
  Name?: string;
  Icon?: string;
  Tooltip?: string;
}
