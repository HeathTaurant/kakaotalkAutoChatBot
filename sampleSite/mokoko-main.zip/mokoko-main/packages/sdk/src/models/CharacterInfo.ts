export interface CharacterInfo {
  ServerName?: string;
  CharacterName?: string;
  CharacterLevel?: number;
  CharacterClassName?: string;
  ItemAvgLevel?: string;
  ItemMaxLevel?: string;
}
