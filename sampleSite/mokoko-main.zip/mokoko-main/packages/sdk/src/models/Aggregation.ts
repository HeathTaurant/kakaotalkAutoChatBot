export interface Aggregation {
  PlayCount?: number;
  VictoryCount?: number;
  LoseCount?: number;
  TieCount?: number;
  KillCount?: number;
  AceCount?: number;
  DeathCount?: number;
}
