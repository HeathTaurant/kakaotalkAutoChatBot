export interface SearchDetailOption {
  FirstOption?: number;
  SecondOption?: number;
  MinValue?: number;
  MaxValue?: number;
}
