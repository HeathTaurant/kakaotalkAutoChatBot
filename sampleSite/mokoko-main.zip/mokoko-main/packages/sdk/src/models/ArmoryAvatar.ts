export interface ArmoryAvatar {
  Type?: string;
  Name?: string;
  Icon?: string;
  Grade?: string;
  IsSet?: boolean;
  IsInner?: boolean;
  Tooltip?: string;
}
