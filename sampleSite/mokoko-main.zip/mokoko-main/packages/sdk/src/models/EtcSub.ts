export interface EtcSub {
  Value?: number;
  Text?: string;
  Class?: string;
}
