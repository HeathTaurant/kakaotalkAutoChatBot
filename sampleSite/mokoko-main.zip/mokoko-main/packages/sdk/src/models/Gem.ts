export interface Gem {
  Slot?: number;
  Name?: string;
  Icon?: string;
  Level?: number;
  Grade?: string;
  Tooltip?: string;
}
