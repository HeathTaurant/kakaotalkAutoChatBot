import type { EtcSub } from "./EtcSub";

export interface EtcOption {
  Value?: number;
  Text?: string;
  EtcSubs?: Array<EtcSub>;
}
