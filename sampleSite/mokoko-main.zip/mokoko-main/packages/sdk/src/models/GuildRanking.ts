export interface GuildRanking {
  Rank?: number;
  GuildName?: string;
  GuildMessage?: string;
  MasterName?: string;
  Rating?: number;
  MemberCount?: number;
  MaxMemberCount?: number;
  UpdatedDate?: string;
}
