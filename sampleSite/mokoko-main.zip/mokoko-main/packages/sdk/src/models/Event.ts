export interface Event {
  Title?: string;
  Thumbnail?: string;
  Link?: string;
  StartDate?: string;
  EndDate?: string;
  RewardDate?: string;
}
