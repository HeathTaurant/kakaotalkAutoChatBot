export interface Tendency {
  Type?: string;
  Point?: number;
  MaxPoint?: number;
}
