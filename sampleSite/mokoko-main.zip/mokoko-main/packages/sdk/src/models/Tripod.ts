export interface Tripod {
  Value?: number;
  Text?: string;
  IsGem?: boolean;
}
