# @mokoko/sdk

## 0.0.6

### Patch Changes

- d134a18: fix unescaped characters error when use custom fetch function

## 0.0.5

### Patch Changes

- b752d37: API v1.1.0, v1.2.0에서 업데이트된 Tooltip data와 Skill Point data를 Model에 추가

## 0.0.4

### Patch Changes

- 66e7d18: better generic fetch interface

## 0.0.3

### Patch Changes

- 557a888: remove node-fetch type dependency

## 0.0.2

### Patch Changes

- 7010c4e: use @shopify/semaphore instead of async-sema
