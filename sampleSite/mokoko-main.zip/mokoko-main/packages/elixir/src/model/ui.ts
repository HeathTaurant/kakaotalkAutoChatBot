export interface UiState {
  selectedSageIndex: number | null;
  selectedEffectIndex: number | null;
}
