export const MAX_LAWFUL = 3;
export const MAX_CHAOS = 6;
