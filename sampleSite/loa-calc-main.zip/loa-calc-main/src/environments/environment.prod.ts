export const environment = {
  production: true,
  marketPriceUrl: 'https://market-cron.icepeng.workers.dev',
};
